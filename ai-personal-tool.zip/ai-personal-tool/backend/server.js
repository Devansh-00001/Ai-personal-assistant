const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3');
const { v4: uuidv4 } = require('uuid');
const Anthropic = require('@anthropic-ai/sdk');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Initialize Claude API
const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

// Database setup
const db = new sqlite3.Database('./assistant.db', (err) => {
  if (err) console.error(err);
  else console.log('Connected to SQLite database');
});

// Initialize database tables
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS tasks (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT,
      priority TEXT DEFAULT 'medium',
      status TEXT DEFAULT 'pending',
      category TEXT,
      dueDate TEXT,
      aiSuggestion TEXT,
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
      updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS notes (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      aiSummary TEXT,
      tags TEXT,
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
      updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS productivity (
      id TEXT PRIMARY KEY,
      date TEXT NOT NULL,
      mood TEXT,
      focusLevel INTEGER,
      tasksCompleted INTEGER DEFAULT 0,
      hoursWorked REAL DEFAULT 0,
      notes TEXT,
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);
});

// ==================== TASKS ENDPOINTS ====================

// Get all tasks
app.get('/api/tasks', (req, res) => {
  const { status, category } = req.query;
  let query = 'SELECT * FROM tasks';
  const params = [];

  if (status || category) {
    query += ' WHERE';
    if (status) {
      query += ' status = ?';
      params.push(status);
    }
    if (category) {
      if (status) query += ' AND';
      query += ' category = ?';
      params.push(category);
    }
  }

  query += ' ORDER BY dueDate ASC, priority DESC';

  db.all(query, params, (err, rows) => {
    if (err) res.status(500).json({ error: err.message });
    else res.json(rows);
  });
});

// Create task with AI suggestion
app.post('/api/tasks', async (req, res) => {
  const { title, description, priority, category, dueDate } = req.body;
  const id = uuidv4();

  try {
    // Get AI suggestion for the task
    const aiSuggestion = await generateTaskSuggestion(title, description);

    db.run(
      `INSERT INTO tasks (id, title, description, priority, category, dueDate, aiSuggestion)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [id, title, description, priority || 'medium', category, dueDate, aiSuggestion],
      function (err) {
        if (err) res.status(500).json({ error: err.message });
        else res.json({ id, title, description, priority, category, dueDate, aiSuggestion });
      }
    );
  } catch (error) {
    res.status(500).json({ error: 'Failed to generate AI suggestion' });
  }
});

// Update task
app.put('/api/tasks/:id', (req, res) => {
  const { id } = req.params;
  const { title, description, priority, status, category, dueDate } = req.body;

  db.run(
    `UPDATE tasks SET title=?, description=?, priority=?, status=?, category=?, dueDate=?, updatedAt=CURRENT_TIMESTAMP
     WHERE id=?`,
    [title, description, priority, status, category, dueDate, id],
    function (err) {
      if (err) res.status(500).json({ error: err.message });
      else res.json({ message: 'Task updated' });
    }
  );
});

// Delete task
app.delete('/api/tasks/:id', (req, res) => {
  const { id } = req.params;
  db.run('DELETE FROM tasks WHERE id=?', [id], function (err) {
    if (err) res.status(500).json({ error: err.message });
    else res.json({ message: 'Task deleted' });
  });
});

// ==================== NOTES ENDPOINTS ====================

// Get all notes
app.get('/api/notes', (req, res) => {
  const query = 'SELECT * FROM notes ORDER BY createdAt DESC';
  db.all(query, (err, rows) => {
    if (err) res.status(500).json({ error: err.message });
    else res.json(rows);
  });
});

// Create note with AI summary
app.post('/api/notes', async (req, res) => {
  const { title, content, tags } = req.body;
  const id = uuidv4();

  try {
    const aiSummary = await generateNoteSummary(content);

    db.run(
      `INSERT INTO notes (id, title, content, aiSummary, tags)
       VALUES (?, ?, ?, ?, ?)`,
      [id, title, content, aiSummary, tags],
      function (err) {
        if (err) res.status(500).json({ error: err.message });
        else res.json({ id, title, content, aiSummary, tags });
      }
    );
  } catch (error) {
    res.status(500).json({ error: 'Failed to generate AI summary' });
  }
});

// Update note
app.put('/api/notes/:id', async (req, res) => {
  const { id } = req.params;
  const { title, content, tags } = req.body;

  try {
    const aiSummary = await generateNoteSummary(content);

    db.run(
      `UPDATE notes SET title=?, content=?, aiSummary=?, tags=?, updatedAt=CURRENT_TIMESTAMP
       WHERE id=?`,
      [title, content, aiSummary, tags, id],
      function (err) {
        if (err) res.status(500).json({ error: err.message });
        else res.json({ message: 'Note updated' });
      }
    );
  } catch (error) {
    res.status(500).json({ error: 'Failed to update note' });
  }
});

// Delete note
app.delete('/api/notes/:id', (req, res) => {
  const { id } = req.params;
  db.run('DELETE FROM notes WHERE id=?', [id], function (err) {
    if (err) res.status(500).json({ error: err.message });
    else res.json({ message: 'Note deleted' });
  });
});

// ==================== PRODUCTIVITY ENDPOINTS ====================

// Get productivity data
app.get('/api/productivity', (req, res) => {
  const { startDate, endDate } = req.query;
  let query = 'SELECT * FROM productivity';
  const params = [];

  if (startDate || endDate) {
    query += ' WHERE';
    if (startDate) {
      query += ' date >= ?';
      params.push(startDate);
    }
    if (endDate) {
      if (startDate) query += ' AND';
      query += ' date <= ?';
      params.push(endDate);
    }
  }

  query += ' ORDER BY date DESC';

  db.all(query, params, (err, rows) => {
    if (err) res.status(500).json({ error: err.message });
    else res.json(rows);
  });
});

// Log productivity
app.post('/api/productivity', (req, res) => {
  const { date, mood, focusLevel, hoursWorked, notes } = req.body;
  const id = uuidv4();

  db.run(
    `INSERT INTO productivity (id, date, mood, focusLevel, hoursWorked, notes)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [id, date, mood, focusLevel, hoursWorked, notes],
    function (err) {
      if (err) res.status(500).json({ error: err.message });
      else res.json({ id, date, mood, focusLevel, hoursWorked, notes });
    }
  );
});

// ==================== AI ANALYSIS ENDPOINTS ====================

// Get AI insights about tasks and productivity
app.post('/api/insights', async (req, res) => {
  try {
    db.all('SELECT * FROM tasks WHERE status != ?', ['completed'], async (err, tasks) => {
      if (err) {
        res.status(500).json({ error: err.message });
        return;
      }

      db.all('SELECT * FROM productivity ORDER BY date DESC LIMIT 7', async (err, recent) => {
        if (err) {
          res.status(500).json({ error: err.message });
          return;
        }

        const insights = await generateInsights(tasks, recent);
        res.json({ insights });
      });
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to generate insights' });
  }
});

// ==================== AI HELPER FUNCTIONS ====================

async function generateTaskSuggestion(title, description) {
  const message = await client.messages.create({
    model: 'claude-opus-4-1',
    max_tokens: 200,
    messages: [
      {
        role: 'user',
        content: `Provide a brief, actionable suggestion for this task:
Title: ${title}
Description: ${description || 'No description provided'}

Keep the suggestion to 1-2 sentences.`,
      },
    ],
  });

  return message.content[0].type === 'text' ? message.content[0].text : 'No suggestion available';
}

async function generateNoteSummary(content) {
  const message = await client.messages.create({
    model: 'claude-opus-4-1',
    max_tokens: 150,
    messages: [
      {
        role: 'user',
        content: `Summarize this note in 2-3 sentences:
${content}`,
      },
    ],
  });

  return message.content[0].type === 'text' ? message.content[0].text : 'No summary available';
}

async function generateInsights(tasks, productivity) {
  const taskSummary = tasks.length > 0 ? `${tasks.length} pending tasks` : 'No pending tasks';
  const recentMood = productivity.length > 0 ? productivity[0].mood : 'Not tracked';

  const message = await client.messages.create({
    model: 'claude-opus-4-1',
    max_tokens: 500,
    messages: [
      {
        role: 'user',
        content: `Generate personalized productivity insights based on this data:
Pending Tasks: ${taskSummary}
Recent Mood: ${recentMood}
Task Categories: ${tasks.map((t) => t.category).join(', ') || 'None set'}
Recent Productivity Entries: ${productivity.length}

Provide 3-4 actionable insights to improve productivity.`,
      },
    ],
  });

  return message.content[0].type === 'text' ? message.content[0].text : 'No insights available';
}

// ==================== ERROR HANDLING & SERVER START ====================

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
