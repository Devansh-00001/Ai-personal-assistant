import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  CheckCircle2,
  Circle,
  Trash2,
  Plus,
  BarChart3,
  FileText,
  Zap,
  Calendar,
  AlertCircle,
} from 'lucide-react';
import TasksSection from './components/TasksSection';
import NotesSection from './components/NotesSection';
import ProductivitySection from './components/ProductivitySection';
import InsightsSection from './components/InsightsSection';
import './App.css';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

function App() {
  const [activeTab, setActiveTab] = useState('tasks');
  const [tasks, setTasks] = useState([]);
  const [notes, setNotes] = useState([]);
  const [productivity, setProductivity] = useState([]);
  const [insights, setInsights] = useState('');
  const [loading, setLoading] = useState(false);

  // Fetch tasks
  const fetchTasks = async () => {
    try {
      const response = await axios.get(`${API_URL}/tasks`);
      setTasks(response.data);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  // Fetch notes
  const fetchNotes = async () => {
    try {
      const response = await axios.get(`${API_URL}/notes`);
      setNotes(response.data);
    } catch (error) {
      console.error('Error fetching notes:', error);
    }
  };

  // Fetch productivity
  const fetchProductivity = async () => {
    try {
      const response = await axios.get(`${API_URL}/productivity`);
      setProductivity(response.data);
    } catch (error) {
      console.error('Error fetching productivity:', error);
    }
  };

  // Generate insights
  const generateInsights = async () => {
    setLoading(true);
    try {
      const response = await axios.post(`${API_URL}/insights`);
      setInsights(response.data.insights);
    } catch (error) {
      console.error('Error generating insights:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
    fetchNotes();
    fetchProductivity();
  }, []);

  return (
    <div className="app">
      <header className="app-header">
        <div className="header-content">
          <div className="logo-section">
            <Zap className="logo-icon" />
            <h1>AI Personal Assistant</h1>
          </div>
          <p className="tagline">Your intelligent productivity companion</p>
        </div>
      </header>

      <nav className="main-nav">
        <button
          className={`nav-button ${activeTab === 'tasks' ? 'active' : ''}`}
          onClick={() => setActiveTab('tasks')}
        >
          <CheckCircle2 size={20} />
          <span>Tasks</span>
        </button>
        <button
          className={`nav-button ${activeTab === 'notes' ? 'active' : ''}`}
          onClick={() => setActiveTab('notes')}
        >
          <FileText size={20} />
          <span>Notes</span>
        </button>
        <button
          className={`nav-button ${activeTab === 'productivity' ? 'active' : ''}`}
          onClick={() => setActiveTab('productivity')}
        >
          <BarChart3 size={20} />
          <span>Productivity</span>
        </button>
        <button
          className={`nav-button ${activeTab === 'insights' ? 'active' : ''}`}
          onClick={() => setActiveTab('insights')}
        >
          <AlertCircle size={20} />
          <span>Insights</span>
        </button>
      </nav>

      <main className="main-content">
        {activeTab === 'tasks' && (
          <TasksSection
            tasks={tasks}
            onTasksChange={() => fetchTasks()}
            apiUrl={API_URL}
          />
        )}

        {activeTab === 'notes' && (
          <NotesSection
            notes={notes}
            onNotesChange={() => fetchNotes()}
            apiUrl={API_URL}
          />
        )}

        {activeTab === 'productivity' && (
          <ProductivitySection
            productivity={productivity}
            onProductivityChange={() => fetchProductivity()}
            apiUrl={API_URL}
          />
        )}

        {activeTab === 'insights' && (
          <InsightsSection
            insights={insights}
            loading={loading}
            onGenerateInsights={generateInsights}
          />
        )}
      </main>
    </div>
  );
}

export default App;
