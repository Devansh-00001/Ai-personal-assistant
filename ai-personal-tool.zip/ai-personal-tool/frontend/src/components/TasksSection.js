import React, { useState } from 'react';
import axios from 'axios';
import { Trash2, Plus, CheckCircle2, Circle, AlertCircle } from 'lucide-react';

function TasksSection({ tasks, onTasksChange, apiUrl }) {
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    priority: 'medium',
    category: '',
    dueDate: '',
  });
  const [filter, setFilter] = useState('all');

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      alert('Please enter a task title');
      return;
    }

    try {
      await axios.post(`${apiUrl}/tasks`, formData);
      setFormData({ title: '', description: '', priority: 'medium', category: '', dueDate: '' });
      setShowForm(false);
      onTasksChange();
    } catch (error) {
      console.error('Error creating task:', error);
    }
  };

  const updateTask = async (id, updates) => {
    try {
      const task = tasks.find((t) => t.id === id);
      await axios.put(`${apiUrl}/tasks/${id}`, { ...task, ...updates });
      onTasksChange();
    } catch (error) {
      console.error('Error updating task:', error);
    }
  };

  const deleteTask = async (id) => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      try {
        await axios.delete(`${apiUrl}/tasks/${id}`);
        onTasksChange();
      } catch (error) {
        console.error('Error deleting task:', error);
      }
    }
  };

  const filteredTasks = tasks.filter((task) => {
    if (filter === 'all') return true;
    return task.status === filter;
  });

  const getPriorityColor = (priority) => {
    const colors = {
      high: 'priority-high',
      medium: 'priority-medium',
      low: 'priority-low',
    };
    return colors[priority] || 'priority-medium';
  };

  return (
    <div className="section">
      <div className="flex-between" style={{ marginBottom: '1.5rem' }}>
        <h2 className="section-title">
          <CheckCircle2 size={24} />
          Tasks
        </h2>
        <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}>
          <Plus size={18} />
          New Task
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="card" style={{ marginBottom: '1.5rem' }}>
          <div className="form-group">
            <label className="form-label">Task Title *</label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleInputChange}
              className="form-input"
              placeholder="What do you need to accomplish?"
            />
          </div>

          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              className="form-textarea"
              placeholder="Add more details about this task..."
            />
          </div>

          <div className="grid grid-2" style={{ marginBottom: '1.25rem' }}>
            <div className="form-group">
              <label className="form-label">Priority</label>
              <select
                name="priority"
                value={formData.priority}
                onChange={handleInputChange}
                className="form-select"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Category</label>
              <input
                type="text"
                name="category"
                value={formData.category}
                onChange={handleInputChange}
                className="form-input"
                placeholder="e.g., Work, Personal"
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Due Date</label>
            <input
              type="date"
              name="dueDate"
              value={formData.dueDate}
              onChange={handleInputChange}
              className="form-input"
            />
          </div>

          <div className="flex-gap">
            <button type="submit" className="btn btn-primary">
              Create Task
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => setShowForm(false)}
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {/* AI Suggestion Display */}
      {filteredTasks.some((t) => t.aiSuggestion) && (
        <div className="card" style={{ background: '#f0fdf4', borderColor: '#bbf7d0', marginBottom: '1.5rem' }}>
          <h3 style={{ color: '#166534', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <AlertCircle size={18} />
            AI Suggestions
          </h3>
          {filteredTasks
            .filter((t) => t.aiSuggestion)
            .map((task) => (
              <p key={task.id} style={{ color: '#15803d', fontSize: '0.9rem', margin: '0.5rem 0' }}>
                <strong>{task.title}:</strong> {task.aiSuggestion}
              </p>
            ))}
        </div>
      )}

      {/* Filters */}
      <div className="flex-gap" style={{ marginBottom: '1.5rem' }}>
        {['all', 'pending', 'in-progress', 'completed'].map((status) => (
          <button
            key={status}
            onClick={() => setFilter(status)}
            className={`btn btn-small ${filter === status ? 'btn-primary' : 'btn-secondary'}`}
          >
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </button>
        ))}
      </div>

      {/* Tasks List */}
      {filteredTasks.length === 0 ? (
        <div className="empty-state">
          <CheckCircle2 className="empty-state-icon" />
          <p className="empty-state-title">No tasks</p>
          <p>Create a task to get started!</p>
        </div>
      ) : (
        <div className="grid">
          {filteredTasks.map((task) => (
            <div key={task.id} className="card">
              <div className="flex-between" style={{ marginBottom: '0.75rem' }}>
                <div style={{ flex: 1 }}>
                  <h3 className="card-title">{task.title}</h3>
                  {task.description && <p className="card-description">{task.description}</p>}
                </div>
                <button
                  className="btn btn-danger"
                  onClick={() => deleteTask(task.id)}
                  title="Delete task"
                >
                  <Trash2 size={16} />
                </button>
              </div>

              <div className="card-meta" style={{ marginBottom: '1rem' }}>
                <span className={`status-badge status-${task.status}`}>{task.status}</span>
                <span className={`priority-badge ${getPriorityColor(task.priority)}`}>
                  {task.priority}
                </span>
                {task.category && <span className="meta-badge">{task.category}</span>}
                {task.dueDate && <span className="meta-badge">{task.dueDate}</span>}
              </div>

              <div className="flex-gap">
                {task.status !== 'completed' && (
                  <button
                    className="btn btn-secondary btn-small"
                    onClick={() => updateTask(task.id, { status: 'completed' })}
                  >
                    <CheckCircle2 size={16} />
                    Mark Complete
                  </button>
                )}
                {task.status === 'pending' && (
                  <button
                    className="btn btn-secondary btn-small"
                    onClick={() => updateTask(task.id, { status: 'in-progress' })}
                  >
                    <Circle size={16} />
                    Start
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default TasksSection;
