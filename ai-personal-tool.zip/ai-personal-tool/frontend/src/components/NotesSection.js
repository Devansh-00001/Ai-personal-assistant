import React, { useState } from 'react';
import axios from 'axios';
import { Trash2, Plus, FileText, Sparkles } from 'lucide-react';

function NotesSection({ notes, onNotesChange, apiUrl }) {
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    tags: '',
  });
  const [searchTerm, setSearchTerm] = useState('');

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title.trim() || !formData.content.trim()) {
      alert('Please enter a title and content');
      return;
    }

    try {
      if (editingId) {
        await axios.put(`${apiUrl}/notes/${editingId}`, formData);
        setEditingId(null);
      } else {
        await axios.post(`${apiUrl}/notes`, formData);
      }
      setFormData({ title: '', content: '', tags: '' });
      setShowForm(false);
      onNotesChange();
    } catch (error) {
      console.error('Error saving note:', error);
    }
  };

  const startEdit = (note) => {
    setFormData(note);
    setEditingId(note.id);
    setShowForm(true);
  };

  const deleteNote = async (id) => {
    if (window.confirm('Are you sure you want to delete this note?')) {
      try {
        await axios.delete(`${apiUrl}/notes/${id}`);
        onNotesChange();
      } catch (error) {
        console.error('Error deleting note:', error);
      }
    }
  };

  const filteredNotes = notes.filter(
    (note) =>
      note.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (note.tags && note.tags.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="section">
      <div className="flex-between" style={{ marginBottom: '1.5rem' }}>
        <h2 className="section-title">
          <FileText size={24} />
          Notes
        </h2>
        <button className="btn btn-primary" onClick={() => {
          setEditingId(null);
          setFormData({ title: '', content: '', tags: '' });
          setShowForm(!showForm);
        }}>
          <Plus size={18} />
          New Note
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="card" style={{ marginBottom: '1.5rem' }}>
          <div className="form-group">
            <label className="form-label">Note Title *</label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleInputChange}
              className="form-input"
              placeholder="Give your note a title..."
            />
          </div>

          <div className="form-group">
            <label className="form-label">Content *</label>
            <textarea
              name="content"
              value={formData.content}
              onChange={handleInputChange}
              className="form-textarea"
              placeholder="Write your note here..."
              style={{ minHeight: '200px' }}
            />
          </div>

          <div className="form-group">
            <label className="form-label">Tags (comma-separated)</label>
            <input
              type="text"
              name="tags"
              value={formData.tags}
              onChange={handleInputChange}
              className="form-input"
              placeholder="e.g., important, ideas, learning"
            />
          </div>

          <div className="flex-gap">
            <button type="submit" className="btn btn-primary">
              {editingId ? 'Update Note' : 'Save Note'}
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => {
                setShowForm(false);
                setEditingId(null);
              }}
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {/* Search */}
      <div className="form-group" style={{ marginBottom: '1.5rem' }}>
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="form-input"
          placeholder="Search notes by title, content, or tags..."
        />
      </div>

      {/* Notes Grid */}
      {filteredNotes.length === 0 ? (
        <div className="empty-state">
          <FileText className="empty-state-icon" />
          <p className="empty-state-title">No notes</p>
          <p>{searchTerm ? 'No notes match your search' : 'Start taking notes to organize your thoughts!'}</p>
        </div>
      ) : (
        <div className="grid grid-2">
          {filteredNotes.map((note) => (
            <div key={note.id} className="card">
              <div className="flex-between" style={{ marginBottom: '0.75rem' }}>
                <h3 className="card-title">{note.title}</h3>
                <button
                  className="btn btn-danger"
                  onClick={() => deleteNote(note.id)}
                  title="Delete note"
                >
                  <Trash2 size={16} />
                </button>
              </div>

              <p className="card-description">{note.content.substring(0, 150)}...</p>

              {note.aiSummary && (
                <div style={{
                  background: '#fef3c7',
                  border: '1px solid #fcd34d',
                  borderRadius: '6px',
                  padding: '0.75rem',
                  marginBottom: '1rem',
                  fontSize: '0.85rem',
                  color: '#92400e',
                  display: 'flex',
                  gap: '0.5rem',
                  alignItems: 'flex-start'
                }}>
                  <Sparkles size={16} style={{ flexShrink: 0, marginTop: '2px' }} />
                  <div>
                    <strong>AI Summary:</strong> {note.aiSummary}
                  </div>
                </div>
              )}

              {note.tags && (
                <div className="card-meta" style={{ marginBottom: '1rem' }}>
                  {note.tags.split(',').map((tag) => (
                    <span key={tag} className="meta-badge">
                      #{tag.trim()}
                    </span>
                  ))}
                </div>
              )}

              <div className="flex-gap">
                <button
                  className="btn btn-secondary btn-small"
                  onClick={() => startEdit(note)}
                >
                  Edit
                </button>
                <span style={{ fontSize: '0.8rem', color: '#9ca3af' }}>
                  {new Date(note.createdAt).toLocaleDateString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default NotesSection;
