import React from 'react';
import { AlertCircle, Sparkles } from 'lucide-react';

function InsightsSection({ insights, loading, onGenerateInsights }) {
  return (
    <div className="section">
      <h2 className="section-title">
        <AlertCircle size={24} />
        AI Insights
      </h2>

      <button
        className="btn btn-primary"
        onClick={onGenerateInsights}
        disabled={loading}
        style={{ marginBottom: '1.5rem' }}
      >
        <Sparkles size={18} />
        {loading ? 'Generating...' : 'Generate Insights'}
      </button>

      {loading && (
        <div className="loading">
          <div className="spinner"></div>
          <span>Analyzing your data...</span>
        </div>
      )}

      {insights && !loading && (
        <div className="card" style={{ background: '#f0fdf4', borderColor: '#bbf7d0' }}>
          <h3 style={{
            color: '#15803d',
            fontSize: '1.25rem',
            fontWeight: '600',
            marginBottom: '1rem',
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem'
          }}>
            <Sparkles size={20} />
            Your Personal Insights
          </h3>
          <div style={{
            color: '#166534',
            lineHeight: '1.8',
            whiteSpace: 'pre-wrap',
            wordBreak: 'break-word'
          }}>
            {insights}
          </div>
        </div>
      )}

      {!insights && !loading && (
        <div className="empty-state">
          <AlertCircle className="empty-state-icon" />
          <p className="empty-state-title">No insights yet</p>
          <p>Click the button above to generate AI-powered insights based on your tasks and productivity data!</p>
        </div>
      )}

      {/* Information Card */}
      <div className="card" style={{ marginTop: '1.5rem', background: '#eff6ff', borderColor: '#bfdbfe' }}>
        <h3 style={{ color: '#1e40af', marginBottom: '0.75rem' }}>
          💡 How It Works
        </h3>
        <ul style={{
          color: '#1e3a8a',
          lineHeight: '1.8',
          paddingLeft: '1.5rem'
        }}>
          <li>AI analyzes your pending tasks and their categories</li>
          <li>Reviews your recent productivity trends and mood patterns</li>
          <li>Generates personalized suggestions to improve your workflow</li>
          <li>Helps identify productivity patterns and opportunities</li>
        </ul>
      </div>
    </div>
  );
}

export default InsightsSection;
