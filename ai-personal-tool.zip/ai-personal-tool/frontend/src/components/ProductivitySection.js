import React, { useState } from 'react';
import axios from 'axios';
import { Plus, BarChart3, Smile, Frown } from 'lucide-react';

function ProductivitySection({ productivity, onProductivityChange, apiUrl }) {
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    mood: 'neutral',
    focusLevel: 5,
    hoursWorked: 0,
    notes: '',
  });

  const moodEmojis = {
    excellent: '😄',
    good: '😊',
    neutral: '😐',
    bad: '😔',
    terrible: '😞',
  };

  const handleInputChange = (e) => {
    const { name, value, type } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${apiUrl}/productivity`, formData);
      setFormData({
        date: new Date().toISOString().split('T')[0],
        mood: 'neutral',
        focusLevel: 5,
        hoursWorked: 0,
        notes: '',
      });
      setShowForm(false);
      onProductivityChange();
    } catch (error) {
      console.error('Error logging productivity:', error);
    }
  };

  const getAverageMood = () => {
    const moodValues = { excellent: 5, good: 4, neutral: 3, bad: 2, terrible: 1 };
    if (productivity.length === 0) return 0;
    const sum = productivity.reduce((acc, p) => acc + (moodValues[p.mood] || 3), 0);
    return (sum / productivity.length).toFixed(1);
  };

  const getAverageFocus = () => {
    if (productivity.length === 0) return 0;
    const sum = productivity.reduce((acc, p) => acc + (p.focusLevel || 0), 0);
    return (sum / productivity.length).toFixed(1);
  };

  const getTotalHours = () => {
    return productivity.reduce((acc, p) => acc + (p.hoursWorked || 0), 0).toFixed(1);
  };

  return (
    <div className="section">
      <div className="flex-between" style={{ marginBottom: '1.5rem' }}>
        <h2 className="section-title">
          <BarChart3 size={24} />
          Productivity Tracker
        </h2>
        <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}>
          <Plus size={18} />
          Log Today
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="card" style={{ marginBottom: '1.5rem' }}>
          <div className="form-group">
            <label className="form-label">Date</label>
            <input
              type="date"
              name="date"
              value={formData.date}
              onChange={handleInputChange}
              className="form-input"
            />
          </div>

          <div className="form-group">
            <label className="form-label">Mood</label>
            <select
              name="mood"
              value={formData.mood}
              onChange={handleInputChange}
              className="form-select"
            >
              <option value="excellent">Excellent 😄</option>
              <option value="good">Good 😊</option>
              <option value="neutral">Neutral 😐</option>
              <option value="bad">Bad 😔</option>
              <option value="terrible">Terrible 😞</option>
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">
              Focus Level: {formData.focusLevel}/10
            </label>
            <input
              type="range"
              name="focusLevel"
              min="1"
              max="10"
              value={formData.focusLevel}
              onChange={handleInputChange}
              className="form-input"
              style={{ cursor: 'pointer' }}
            />
          </div>

          <div className="form-group">
            <label className="form-label">Hours Worked</label>
            <input
              type="number"
              name="hoursWorked"
              min="0"
              step="0.5"
              value={formData.hoursWorked}
              onChange={handleInputChange}
              className="form-input"
              placeholder="e.g., 8.5"
            />
          </div>

          <div className="form-group">
            <label className="form-label">Notes</label>
            <textarea
              name="notes"
              value={formData.notes}
              onChange={handleInputChange}
              className="form-textarea"
              placeholder="What did you accomplish today?"
              style={{ minHeight: '100px' }}
            />
          </div>

          <div className="flex-gap">
            <button type="submit" className="btn btn-primary">
              Log Entry
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => setShowForm(false)}
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {/* Stats Overview */}
      {productivity.length > 0 && (
        <div className="grid grid-2" style={{ marginBottom: '1.5rem' }}>
          <div className="card" style={{ background: '#fef3c7', borderColor: '#fcd34d' }}>
            <p style={{ color: '#92400e', fontSize: '0.85rem', margin: '0 0 0.5rem' }}>
              Average Mood
            </p>
            <p style={{ color: '#78350f', fontSize: '1.75rem', fontWeight: '700', margin: 0 }}>
              {moodEmojis[
                ['terrible', 'bad', 'neutral', 'good', 'excellent'][
                  Math.round(parseFloat(getAverageMood())) - 1
                ] || 'neutral'
              ]}{' '}
              {getAverageMood()}
            </p>
          </div>

          <div className="card" style={{ background: '#dbeafe', borderColor: '#bfdbfe' }}>
            <p style={{ color: '#1e40af', fontSize: '0.85rem', margin: '0 0 0.5rem' }}>
              Average Focus
            </p>
            <p style={{ color: '#1e3a8a', fontSize: '1.75rem', fontWeight: '700', margin: 0 }}>
              {getAverageFocus()}/10
            </p>
          </div>

          <div className="card" style={{ background: '#dcfce7', borderColor: '#bbf7d0' }}>
            <p style={{ color: '#15803d', fontSize: '0.85rem', margin: '0 0 0.5rem' }}>
              Total Hours
            </p>
            <p style={{ color: '#166534', fontSize: '1.75rem', fontWeight: '700', margin: 0 }}>
              {getTotalHours()}h
            </p>
          </div>

          <div className="card" style={{ background: '#f3e8ff', borderColor: '#e9d5ff' }}>
            <p style={{ color: '#6b21a8', fontSize: '0.85rem', margin: '0 0 0.5rem' }}>
              Total Entries
            </p>
            <p style={{ color: '#581c87', fontSize: '1.75rem', fontWeight: '700', margin: 0 }}>
              {productivity.length}
            </p>
          </div>
        </div>
      )}

      {/* Productivity Log */}
      {productivity.length === 0 ? (
        <div className="empty-state">
          <BarChart3 className="empty-state-icon" />
          <p className="empty-state-title">No entries yet</p>
          <p>Start tracking your productivity to see insights!</p>
        </div>
      ) : (
        <div className="grid">
          {productivity.map((entry) => (
            <div key={entry.id} className="card">
              <div style={{ marginBottom: '1rem' }}>
                <h3 className="card-title">
                  {new Date(entry.date).toLocaleDateString('en-US', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                  })}
                </h3>
              </div>

              <div className="card-meta" style={{ marginBottom: '1rem' }}>
                <span className="meta-badge">
                  {moodEmojis[entry.mood] || '😐'} {entry.mood}
                </span>
                <span className="meta-badge">Focus: {entry.focusLevel}/10</span>
                <span className="meta-badge">⏱️ {entry.hoursWorked}h</span>
              </div>

              {entry.notes && <p className="card-description">{entry.notes}</p>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default ProductivitySection;
