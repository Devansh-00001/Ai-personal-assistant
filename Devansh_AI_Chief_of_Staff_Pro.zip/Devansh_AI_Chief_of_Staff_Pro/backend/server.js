/*
  AI Chief of Staff Pro
  Created by Devansh Bhargava
  Portfolio-grade backend: auth, dashboard, productivity modules, AI fallback.
*/

require('dotenv').config();

const fs = require('fs');
const path = require('path');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');

const PORT = Number(process.env.PORT || 5000);
const JWT_SECRET = process.env.JWT_SECRET || 'devansh_dev_secret_change_me';
const DATA_DIR = path.join(__dirname, 'data');
const DB_PATH = path.join(DATA_DIR, 'assistant.db');

fs.mkdirSync(DATA_DIR, { recursive: true });

const app = express();
const db = new sqlite3.Database(DB_PATH);

app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL || true, credentials: true }));
app.use(express.json({ limit: '64kb' }));
app.use(morgan('dev'));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 250, standardHeaders: true, legacyHeaders: false }));

const aiLimiter = rateLimit({ windowMs: 60 * 1000, max: 8, standardHeaders: true, legacyHeaders: false });

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function callback(err) {
      if (err) reject(err);
      else resolve({ id: this.lastID, changes: this.changes });
    });
  });
}

function get(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => (err ? reject(err) : resolve(row)));
  });
}

function all(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => (err ? reject(err) : resolve(rows)));
  });
}

function trim(value, max = 255) {
  if (typeof value !== 'string') return '';
  return value.trim().slice(0, max);
}

function numberOr(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function requireText(body, field, max = 255) {
  const value = trim(body[field], max);
  if (!value) {
    const err = new Error(`${field} is required`);
    err.status = 400;
    throw err;
  }
  return value;
}

function signToken(user) {
  return jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
}

function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing auth token' });

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    return next();
  } catch (error) {
    return res.status(401).json({ error: 'Invalid or expired auth token' });
  }
}

async function initDatabase() {
  await run('PRAGMA foreign_keys = ON');
  await run(`CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    passwordHash TEXT NOT NULL,
    createdAt TEXT DEFAULT CURRENT_TIMESTAMP
  )`);

  await run(`CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    userId TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT DEFAULT '',
    status TEXT DEFAULT 'todo',
    priority TEXT DEFAULT 'medium',
    dueDate TEXT,
    category TEXT DEFAULT 'General',
    createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
    updatedAt TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(userId) REFERENCES users(id) ON DELETE CASCADE
  )`);

  await run(`CREATE TABLE IF NOT EXISTS goals (
    id TEXT PRIMARY KEY,
    userId TEXT NOT NULL,
    title TEXT NOT NULL,
    why TEXT DEFAULT '',
    deadline TEXT,
    status TEXT DEFAULT 'active',
    progress INTEGER DEFAULT 0,
    createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
    updatedAt TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(userId) REFERENCES users(id) ON DELETE CASCADE
  )`);

  await run(`CREATE TABLE IF NOT EXISTS reminders (
    id TEXT PRIMARY KEY,
    userId TEXT NOT NULL,
    title TEXT NOT NULL,
    remindAt TEXT NOT NULL,
    channel TEXT DEFAULT 'in-app',
    status TEXT DEFAULT 'scheduled',
    createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
    updatedAt TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(userId) REFERENCES users(id) ON DELETE CASCADE
  )`);

  await run(`CREATE TABLE IF NOT EXISTS appointments (
    id TEXT PRIMARY KEY,
    userId TEXT NOT NULL,
    title TEXT NOT NULL,
    startsAt TEXT NOT NULL,
    endsAt TEXT,
    location TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
    updatedAt TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(userId) REFERENCES users(id) ON DELETE CASCADE
  )`);

  await run(`CREATE TABLE IF NOT EXISTS mood_entries (
    id TEXT PRIMARY KEY,
    userId TEXT NOT NULL,
    mood TEXT NOT NULL,
    energy INTEGER DEFAULT 5,
    stress INTEGER DEFAULT 5,
    note TEXT DEFAULT '',
    createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(userId) REFERENCES users(id) ON DELETE CASCADE
  )`);

  await run(`CREATE TABLE IF NOT EXISTS habits (
    id TEXT PRIMARY KEY,
    userId TEXT NOT NULL,
    title TEXT NOT NULL,
    targetFrequency TEXT DEFAULT 'daily',
    createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
    updatedAt TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(userId) REFERENCES users(id) ON DELETE CASCADE
  )`);

  await run(`CREATE TABLE IF NOT EXISTS habit_logs (
    id TEXT PRIMARY KEY,
    userId TEXT NOT NULL,
    habitId TEXT NOT NULL,
    logDate TEXT NOT NULL,
    completed INTEGER DEFAULT 1,
    createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(userId, habitId, logDate),
    FOREIGN KEY(userId) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY(habitId) REFERENCES habits(id) ON DELETE CASCADE
  )`);

  await run(`CREATE TABLE IF NOT EXISTS finance_entries (
    id TEXT PRIMARY KEY,
    userId TEXT NOT NULL,
    type TEXT NOT NULL,
    amount REAL NOT NULL,
    category TEXT DEFAULT 'General',
    note TEXT DEFAULT '',
    entryDate TEXT DEFAULT CURRENT_DATE,
    createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(userId) REFERENCES users(id) ON DELETE CASCADE
  )`);

  await run(`CREATE TABLE IF NOT EXISTS notes (
    id TEXT PRIMARY KEY,
    userId TEXT NOT NULL,
    title TEXT NOT NULL,
    content TEXT DEFAULT '',
    createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
    updatedAt TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(userId) REFERENCES users(id) ON DELETE CASCADE
  )`);
}

async function seedStarterData(userId) {
  const taskId = uuidv4();
  const goalId = uuidv4();
  const habitId = uuidv4();
  const reminderId = uuidv4();
  const appointmentId = uuidv4();
  const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().slice(0, 16);
  const nextWeek = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);

  await run('INSERT INTO goals(id,userId,title,why,deadline,progress) VALUES(?,?,?,?,?,?)', [
    goalId,
    userId,
    'Build a high-impact portfolio',
    'Show recruiters full-stack + AI product thinking',
    nextWeek,
    20
  ]);
  await run('INSERT INTO tasks(id,userId,title,description,priority,dueDate,category) VALUES(?,?,?,?,?,?,?)', [
    taskId,
    userId,
    'Record a 90-second demo video',
    'Walk through dashboard, AI brief, and goal breakdown.',
    'high',
    nextWeek,
    'Portfolio'
  ]);
  await run('INSERT INTO habits(id,userId,title,targetFrequency) VALUES(?,?,?,?)', [habitId, userId, 'Daily deep work block', 'daily']);
  await run('INSERT INTO reminders(id,userId,title,remindAt,channel) VALUES(?,?,?,?,?)', [reminderId, userId, 'Review today\'s CEO brief', tomorrow, 'in-app']);
  await run('INSERT INTO appointments(id,userId,title,startsAt,endsAt,location,notes) VALUES(?,?,?,?,?,?,?)', [appointmentId, userId, 'Portfolio review session', tomorrow, '', 'Online', 'Check README and deployment flow.']);
}

app.get('/health', (req, res) => {
  res.json({ status: 'ok', app: 'AI Chief of Staff Pro', author: 'Devansh Bhargava' });
});

app.post('/api/auth/register', async (req, res, next) => {
  try {
    const name = requireText(req.body, 'name', 80);
    const email = requireText(req.body, 'email', 120).toLowerCase();
    const password = requireText(req.body, 'password', 128);

    if (!email.includes('@')) return res.status(400).json({ error: 'Valid email is required' });
    if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });

    const existing = await get('SELECT id FROM users WHERE email=?', [email]);
    if (existing) return res.status(409).json({ error: 'Email already registered' });

    const id = uuidv4();
    const passwordHash = await bcrypt.hash(password, 12);
    await run('INSERT INTO users(id,name,email,passwordHash) VALUES(?,?,?,?)', [id, name, email, passwordHash]);
    await seedStarterData(id);

    const user = { id, name, email };
    res.status(201).json({ user, token: signToken(user) });
  } catch (error) {
    next(error);
  }
});

app.post('/api/auth/login', async (req, res, next) => {
  try {
    const email = requireText(req.body, 'email', 120).toLowerCase();
    const password = requireText(req.body, 'password', 128);
    const user = await get('SELECT * FROM users WHERE email=?', [email]);
    if (!user) return res.status(401).json({ error: 'Invalid email or password' });
    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) return res.status(401).json({ error: 'Invalid email or password' });
    res.json({ user: { id: user.id, name: user.name, email: user.email }, token: signToken(user) });
  } catch (error) {
    next(error);
  }
});

app.get('/api/auth/me', auth, async (req, res, next) => {
  try {
    const user = await get('SELECT id,name,email,createdAt FROM users WHERE id=?', [req.user.userId]);
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json({ user });
  } catch (error) {
    next(error);
  }
});

app.get('/api/dashboard', auth, async (req, res, next) => {
  try {
    const userId = req.user.userId;
    const [tasks, goals, reminders, appointments, moods, habits, finance] = await Promise.all([
      all('SELECT status,priority,COUNT(*) as count FROM tasks WHERE userId=? GROUP BY status,priority', [userId]),
      all('SELECT * FROM goals WHERE userId=? ORDER BY createdAt DESC LIMIT 6', [userId]),
      all('SELECT * FROM reminders WHERE userId=? AND status != ? ORDER BY remindAt ASC LIMIT 6', [userId, 'done']),
      all('SELECT * FROM appointments WHERE userId=? ORDER BY startsAt ASC LIMIT 6', [userId]),
      all('SELECT * FROM mood_entries WHERE userId=? ORDER BY createdAt DESC LIMIT 7', [userId]),
      all(`SELECT h.*, COUNT(l.id) as completions
           FROM habits h LEFT JOIN habit_logs l ON h.id=l.habitId
           WHERE h.userId=? GROUP BY h.id ORDER BY h.createdAt DESC LIMIT 8`, [userId]),
      all('SELECT type, SUM(amount) as total FROM finance_entries WHERE userId=? GROUP BY type', [userId])
    ]);

    const taskSummary = tasks.reduce((acc, row) => {
      acc.total += row.count;
      acc[row.status] = (acc[row.status] || 0) + row.count;
      if (row.priority === 'high') acc.highPriority += row.count;
      return acc;
    }, { total: 0, todo: 0, doing: 0, done: 0, highPriority: 0 });

    const financeSummary = finance.reduce((acc, row) => {
      acc[row.type] = Number(row.total || 0);
      acc.balance = (acc.income || 0) - (acc.expense || 0);
      return acc;
    }, { income: 0, expense: 0, balance: 0 });

    res.json({ taskSummary, goals, reminders, appointments, moods, habits, financeSummary });
  } catch (error) {
    next(error);
  }
});

app.get('/api/tasks', auth, async (req, res, next) => {
  try {
    res.json(await all('SELECT * FROM tasks WHERE userId=? ORDER BY createdAt DESC', [req.user.userId]));
  } catch (error) { next(error); }
});

app.post('/api/tasks', auth, async (req, res, next) => {
  try {
    const id = uuidv4();
    const item = {
      title: requireText(req.body, 'title', 160),
      description: trim(req.body.description, 800),
      status: ['todo', 'doing', 'done'].includes(req.body.status) ? req.body.status : 'todo',
      priority: ['low', 'medium', 'high'].includes(req.body.priority) ? req.body.priority : 'medium',
      dueDate: trim(req.body.dueDate, 40) || null,
      category: trim(req.body.category, 80) || 'General'
    };
    await run('INSERT INTO tasks(id,userId,title,description,status,priority,dueDate,category) VALUES(?,?,?,?,?,?,?,?)', [id, req.user.userId, item.title, item.description, item.status, item.priority, item.dueDate, item.category]);
    res.status(201).json({ id, ...item });
  } catch (error) { next(error); }
});

app.patch('/api/tasks/:id', auth, async (req, res, next) => {
  try {
    const current = await get('SELECT * FROM tasks WHERE id=? AND userId=?', [req.params.id, req.user.userId]);
    if (!current) return res.status(404).json({ error: 'Task not found' });
    const updated = {
      title: trim(req.body.title, 160) || current.title,
      description: req.body.description === undefined ? current.description : trim(req.body.description, 800),
      status: ['todo', 'doing', 'done'].includes(req.body.status) ? req.body.status : current.status,
      priority: ['low', 'medium', 'high'].includes(req.body.priority) ? req.body.priority : current.priority,
      dueDate: req.body.dueDate === undefined ? current.dueDate : trim(req.body.dueDate, 40),
      category: req.body.category === undefined ? current.category : trim(req.body.category, 80)
    };
    await run('UPDATE tasks SET title=?,description=?,status=?,priority=?,dueDate=?,category=?,updatedAt=CURRENT_TIMESTAMP WHERE id=? AND userId=?', [updated.title, updated.description, updated.status, updated.priority, updated.dueDate, updated.category, req.params.id, req.user.userId]);
    res.json({ id: req.params.id, ...updated });
  } catch (error) { next(error); }
});

app.delete('/api/tasks/:id', auth, async (req, res, next) => {
  try {
    await run('DELETE FROM tasks WHERE id=? AND userId=?', [req.params.id, req.user.userId]);
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.get('/api/goals', auth, async (req, res, next) => {
  try { res.json(await all('SELECT * FROM goals WHERE userId=? ORDER BY createdAt DESC', [req.user.userId])); } catch (error) { next(error); }
});

app.post('/api/goals', auth, async (req, res, next) => {
  try {
    const id = uuidv4();
    const title = requireText(req.body, 'title', 180);
    const why = trim(req.body.why, 700);
    const deadline = trim(req.body.deadline, 40) || null;
    const progress = Math.max(0, Math.min(100, numberOr(req.body.progress, 0)));
    await run('INSERT INTO goals(id,userId,title,why,deadline,progress) VALUES(?,?,?,?,?,?)', [id, req.user.userId, title, why, deadline, progress]);
    res.status(201).json({ id, title, why, deadline, progress, status: 'active' });
  } catch (error) { next(error); }
});

app.patch('/api/goals/:id', auth, async (req, res, next) => {
  try {
    const current = await get('SELECT * FROM goals WHERE id=? AND userId=?', [req.params.id, req.user.userId]);
    if (!current) return res.status(404).json({ error: 'Goal not found' });
    const title = trim(req.body.title, 180) || current.title;
    const why = req.body.why === undefined ? current.why : trim(req.body.why, 700);
    const deadline = req.body.deadline === undefined ? current.deadline : trim(req.body.deadline, 40);
    const status = ['active', 'paused', 'completed'].includes(req.body.status) ? req.body.status : current.status;
    const progress = Math.max(0, Math.min(100, numberOr(req.body.progress, current.progress)));
    await run('UPDATE goals SET title=?,why=?,deadline=?,status=?,progress=?,updatedAt=CURRENT_TIMESTAMP WHERE id=? AND userId=?', [title, why, deadline, status, progress, req.params.id, req.user.userId]);
    res.json({ id: req.params.id, title, why, deadline, status, progress });
  } catch (error) { next(error); }
});

app.delete('/api/goals/:id', auth, async (req, res, next) => {
  try { await run('DELETE FROM goals WHERE id=? AND userId=?', [req.params.id, req.user.userId]); res.json({ ok: true }); } catch (error) { next(error); }
});

app.get('/api/reminders', auth, async (req, res, next) => {
  try { res.json(await all('SELECT * FROM reminders WHERE userId=? ORDER BY remindAt ASC', [req.user.userId])); } catch (error) { next(error); }
});

app.post('/api/reminders', auth, async (req, res, next) => {
  try {
    const id = uuidv4();
    const title = requireText(req.body, 'title', 160);
    const remindAt = requireText(req.body, 'remindAt', 40);
    const channel = trim(req.body.channel, 40) || 'in-app';
    await run('INSERT INTO reminders(id,userId,title,remindAt,channel) VALUES(?,?,?,?,?)', [id, req.user.userId, title, remindAt, channel]);
    res.status(201).json({ id, title, remindAt, channel, status: 'scheduled' });
  } catch (error) { next(error); }
});

app.patch('/api/reminders/:id', auth, async (req, res, next) => {
  try {
    const status = ['scheduled', 'done', 'missed'].includes(req.body.status) ? req.body.status : 'done';
    await run('UPDATE reminders SET status=?,updatedAt=CURRENT_TIMESTAMP WHERE id=? AND userId=?', [status, req.params.id, req.user.userId]);
    res.json({ ok: true, status });
  } catch (error) { next(error); }
});

app.delete('/api/reminders/:id', auth, async (req, res, next) => {
  try { await run('DELETE FROM reminders WHERE id=? AND userId=?', [req.params.id, req.user.userId]); res.json({ ok: true }); } catch (error) { next(error); }
});

app.get('/api/appointments', auth, async (req, res, next) => {
  try { res.json(await all('SELECT * FROM appointments WHERE userId=? ORDER BY startsAt ASC', [req.user.userId])); } catch (error) { next(error); }
});

app.post('/api/appointments', auth, async (req, res, next) => {
  try {
    const id = uuidv4();
    const title = requireText(req.body, 'title', 160);
    const startsAt = requireText(req.body, 'startsAt', 40);
    const endsAt = trim(req.body.endsAt, 40);
    const location = trim(req.body.location, 120);
    const notes = trim(req.body.notes, 600);
    await run('INSERT INTO appointments(id,userId,title,startsAt,endsAt,location,notes) VALUES(?,?,?,?,?,?,?)', [id, req.user.userId, title, startsAt, endsAt, location, notes]);
    res.status(201).json({ id, title, startsAt, endsAt, location, notes });
  } catch (error) { next(error); }
});

app.delete('/api/appointments/:id', auth, async (req, res, next) => {
  try { await run('DELETE FROM appointments WHERE id=? AND userId=?', [req.params.id, req.user.userId]); res.json({ ok: true }); } catch (error) { next(error); }
});

app.get('/api/moods', auth, async (req, res, next) => {
  try { res.json(await all('SELECT * FROM mood_entries WHERE userId=? ORDER BY createdAt DESC', [req.user.userId])); } catch (error) { next(error); }
});

app.post('/api/moods', auth, async (req, res, next) => {
  try {
    const id = uuidv4();
    const mood = requireText(req.body, 'mood', 60);
    const energy = Math.max(1, Math.min(10, numberOr(req.body.energy, 5)));
    const stress = Math.max(1, Math.min(10, numberOr(req.body.stress, 5)));
    const note = trim(req.body.note, 800);
    await run('INSERT INTO mood_entries(id,userId,mood,energy,stress,note) VALUES(?,?,?,?,?,?)', [id, req.user.userId, mood, energy, stress, note]);
    res.status(201).json({ id, mood, energy, stress, note });
  } catch (error) { next(error); }
});

app.get('/api/habits', auth, async (req, res, next) => {
  try {
    const rows = await all(`SELECT h.*, COUNT(l.id) as completions
      FROM habits h LEFT JOIN habit_logs l ON h.id=l.habitId
      WHERE h.userId=? GROUP BY h.id ORDER BY h.createdAt DESC`, [req.user.userId]);
    res.json(rows);
  } catch (error) { next(error); }
});

app.post('/api/habits', auth, async (req, res, next) => {
  try {
    const id = uuidv4();
    const title = requireText(req.body, 'title', 160);
    const targetFrequency = trim(req.body.targetFrequency, 40) || 'daily';
    await run('INSERT INTO habits(id,userId,title,targetFrequency) VALUES(?,?,?,?)', [id, req.user.userId, title, targetFrequency]);
    res.status(201).json({ id, title, targetFrequency });
  } catch (error) { next(error); }
});

app.post('/api/habits/:id/log', auth, async (req, res, next) => {
  try {
    const habit = await get('SELECT id FROM habits WHERE id=? AND userId=?', [req.params.id, req.user.userId]);
    if (!habit) return res.status(404).json({ error: 'Habit not found' });
    const id = uuidv4();
    const logDate = trim(req.body.logDate, 20) || new Date().toISOString().slice(0, 10);
    await run('INSERT OR REPLACE INTO habit_logs(id,userId,habitId,logDate,completed) VALUES(?,?,?,?,1)', [id, req.user.userId, req.params.id, logDate]);
    res.status(201).json({ id, habitId: req.params.id, logDate, completed: true });
  } catch (error) { next(error); }
});

app.delete('/api/habits/:id', auth, async (req, res, next) => {
  try { await run('DELETE FROM habits WHERE id=? AND userId=?', [req.params.id, req.user.userId]); res.json({ ok: true }); } catch (error) { next(error); }
});

app.get('/api/finance', auth, async (req, res, next) => {
  try { res.json(await all('SELECT * FROM finance_entries WHERE userId=? ORDER BY entryDate DESC, createdAt DESC', [req.user.userId])); } catch (error) { next(error); }
});

app.post('/api/finance', auth, async (req, res, next) => {
  try {
    const id = uuidv4();
    const type = req.body.type === 'income' ? 'income' : 'expense';
    const amount = Math.max(0, numberOr(req.body.amount, 0));
    if (!amount) return res.status(400).json({ error: 'Amount must be greater than zero' });
    const category = trim(req.body.category, 80) || 'General';
    const note = trim(req.body.note, 400);
    const entryDate = trim(req.body.entryDate, 20) || new Date().toISOString().slice(0, 10);
    await run('INSERT INTO finance_entries(id,userId,type,amount,category,note,entryDate) VALUES(?,?,?,?,?,?,?)', [id, req.user.userId, type, amount, category, note, entryDate]);
    res.status(201).json({ id, type, amount, category, note, entryDate });
  } catch (error) { next(error); }
});

app.delete('/api/finance/:id', auth, async (req, res, next) => {
  try { await run('DELETE FROM finance_entries WHERE id=? AND userId=?', [req.params.id, req.user.userId]); res.json({ ok: true }); } catch (error) { next(error); }
});

app.get('/api/notes', auth, async (req, res, next) => {
  try { res.json(await all('SELECT * FROM notes WHERE userId=? ORDER BY updatedAt DESC', [req.user.userId])); } catch (error) { next(error); }
});

app.post('/api/notes', auth, async (req, res, next) => {
  try {
    const id = uuidv4();
    const title = requireText(req.body, 'title', 160);
    const content = trim(req.body.content, 5000);
    await run('INSERT INTO notes(id,userId,title,content) VALUES(?,?,?,?)', [id, req.user.userId, title, content]);
    res.status(201).json({ id, title, content });
  } catch (error) { next(error); }
});

app.delete('/api/notes/:id', auth, async (req, res, next) => {
  try { await run('DELETE FROM notes WHERE id=? AND userId=?', [req.params.id, req.user.userId]); res.json({ ok: true }); } catch (error) { next(error); }
});

function localDailyBrief(data) {
  const todo = data.taskSummary.todo || 0;
  const high = data.taskSummary.highPriority || 0;
  const goal = data.goals[0]?.title || 'your top goal';
  const nextReminder = data.reminders[0]?.title || 'no urgent reminders';
  const mood = data.moods[0]?.mood || 'not logged yet';
  return [
    `Good morning, Devansh. Today your operating system shows ${todo} open tasks and ${high} high-priority items.`,
    `Your current anchor goal is: ${goal}. Protect one deep-work block for it today.`,
    `Next reminder: ${nextReminder}.`,
    `Latest mood signal: ${mood}. Keep the day simple: one win for career, one win for health, one win for discipline.`
  ].join('\n\n');
}

function localGoalBreakdown(title) {
  return [
    `1. Define the exact outcome for: ${title}`,
    '2. Break it into a 7-day execution sprint.',
    '3. Add three high-priority tasks with deadlines.',
    '4. Schedule one appointment or deep-work block for progress.',
    '5. Review progress every night and update the goal percentage.'
  ].join('\n');
}

async function askClaude(prompt) {
  if (!process.env.ANTHROPIC_API_KEY) return null;
  try {
    const sdk = require('@anthropic-ai/sdk');
    const Anthropic = sdk.default || sdk;
    const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
    const response = await anthropic.messages.create({
      model: process.env.CLAUDE_MODEL || 'claude-3-5-sonnet-latest',
      max_tokens: 600,
      temperature: 0.4,
      messages: [{ role: 'user', content: prompt }]
    });
    return response.content?.[0]?.text || null;
  } catch (error) {
    console.warn('Claude fallback used:', error.message);
    return null;
  }
}

app.post('/api/ai/daily-brief', auth, aiLimiter, async (req, res, next) => {
  try {
    const dashboardReq = { user: req.user };
    const userId = dashboardReq.user.userId;
    const tasks = await all('SELECT status,priority,COUNT(*) as count FROM tasks WHERE userId=? GROUP BY status,priority', [userId]);
    const taskSummary = tasks.reduce((acc, row) => {
      acc.total += row.count;
      acc[row.status] = (acc[row.status] || 0) + row.count;
      if (row.priority === 'high') acc.highPriority += row.count;
      return acc;
    }, { total: 0, todo: 0, doing: 0, done: 0, highPriority: 0 });
    const data = {
      taskSummary,
      goals: await all('SELECT * FROM goals WHERE userId=? ORDER BY createdAt DESC LIMIT 3', [userId]),
      reminders: await all('SELECT * FROM reminders WHERE userId=? AND status=? ORDER BY remindAt ASC LIMIT 3', [userId, 'scheduled']),
      moods: await all('SELECT * FROM mood_entries WHERE userId=? ORDER BY createdAt DESC LIMIT 3', [userId])
    };
    const prompt = `Create a concise executive daily brief for Devansh from this JSON. Be direct, motivating, and action-focused. JSON: ${JSON.stringify(data)}`;
    const ai = await askClaude(prompt);
    res.json({ source: ai ? 'claude' : 'local-fallback', brief: ai || localDailyBrief(data) });
  } catch (error) { next(error); }
});

app.post('/api/ai/goal-breakdown', auth, aiLimiter, async (req, res, next) => {
  try {
    const title = requireText(req.body, 'title', 180);
    const prompt = `Break this goal into a practical 7-day execution plan with clear tasks. Goal: ${title}`;
    const ai = await askClaude(prompt);
    res.json({ source: ai ? 'claude' : 'local-fallback', plan: ai || localGoalBreakdown(title) });
  } catch (error) { next(error); }
});

app.use((req, res) => res.status(404).json({ error: 'Route not found' }));

app.use((err, req, res, next) => {
  const status = err.status || 500;
  console.error(err);
  res.status(status).json({ error: status === 500 ? 'Internal server error' : err.message });
});

initDatabase()
  .then(() => {
    app.listen(PORT, () => console.log(`AI Chief of Staff Pro backend running on http://localhost:${PORT}`));
  })
  .catch((error) => {
    console.error('Failed to initialize database', error);
    process.exit(1);
  });
