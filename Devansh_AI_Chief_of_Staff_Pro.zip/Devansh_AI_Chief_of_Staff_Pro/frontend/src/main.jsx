import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Brain, Calendar, CheckCircle2, CircleDollarSign, Clock, Flame, LayoutDashboard, ListTodo, LogOut, Moon, NotebookPen, Rocket, ShieldCheck, Target, TrendingUp } from 'lucide-react';
import './styles.css';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';
const tabs = [
  ['dashboard', 'Dashboard', LayoutDashboard],
  ['tasks', 'Tasks', ListTodo],
  ['goals', 'Goals', Target],
  ['reminders', 'Reminders', Clock],
  ['appointments', 'Appointments', Calendar],
  ['mood', 'Mood', Moon],
  ['habits', 'Habits', Flame],
  ['finance', 'Finance', CircleDollarSign],
  ['notes', 'Notes', NotebookPen],
  ['ai', 'AI Brief', Brain]
];

function App() {
  const [token, setToken] = useState(localStorage.getItem('chief_token') || '');
  const [user, setUser] = useState(null);
  const [active, setActive] = useState('dashboard');
  const [data, setData] = useState({});
  const [message, setMessage] = useState('');

  const api = useMemo(() => async (path, options = {}) => {
    const response = await fetch(`${API_URL}${path}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(options.headers || {})
      }
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || 'Request failed');
    return payload;
  }, [token]);

  async function refresh() {
    if (!token) return;
    try {
      const [me, dashboard, tasks, goals, reminders, appointments, moods, habits, finance, notes] = await Promise.all([
        api('/api/auth/me'),
        api('/api/dashboard'),
        api('/api/tasks'),
        api('/api/goals'),
        api('/api/reminders'),
        api('/api/appointments'),
        api('/api/moods'),
        api('/api/habits'),
        api('/api/finance'),
        api('/api/notes')
      ]);
      setUser(me.user);
      setData({ dashboard, tasks, goals, reminders, appointments, moods, habits, finance, notes });
      setMessage('');
    } catch (error) {
      setMessage(error.message);
      if (error.message.toLowerCase().includes('token')) logout();
    }
  }

  useEffect(() => { refresh(); }, [token]);

  function logout() {
    localStorage.removeItem('chief_token');
    setToken('');
    setUser(null);
    setData({});
  }

  if (!token) return <AuthScreen setToken={setToken} setMessage={setMessage} message={message} />;

  const ActiveIcon = tabs.find(([id]) => id === active)?.[2] || LayoutDashboard;

  return (
    <div className="appShell">
      <aside className="sidebar">
        <div className="brand">
          <div className="logo"><Rocket size={22} /></div>
          <div>
            <strong>AI Chief of Staff Pro</strong>
            <span>by Devansh Bhargava</span>
          </div>
        </div>
        <nav>
          {tabs.map(([id, label, Icon]) => (
            <button key={id} onClick={() => setActive(id)} className={active === id ? 'active' : ''}>
              <Icon size={18} /> {label}
            </button>
          ))}
        </nav>
        <button className="logout" onClick={logout}><LogOut size={18} /> Logout</button>
      </aside>

      <main className="content">
        <header className="topbar">
          <div>
            <p className="eyebrow">Personal execution operating system</p>
            <h1><ActiveIcon size={28} /> {tabs.find(([id]) => id === active)?.[1]}</h1>
          </div>
          <div className="profileCard">
            <ShieldCheck size={18} />
            <div><strong>{user?.name || 'Devansh'}</strong><span>{user?.email}</span></div>
          </div>
        </header>

        {message && <div className="alert">{message}</div>}
        {active === 'dashboard' && <Dashboard data={data.dashboard} />}
        {active === 'tasks' && <Tasks api={api} items={data.tasks || []} refresh={refresh} />}
        {active === 'goals' && <Goals api={api} items={data.goals || []} refresh={refresh} />}
        {active === 'reminders' && <Reminders api={api} items={data.reminders || []} refresh={refresh} />}
        {active === 'appointments' && <Appointments api={api} items={data.appointments || []} refresh={refresh} />}
        {active === 'mood' && <Mood api={api} items={data.moods || []} refresh={refresh} />}
        {active === 'habits' && <Habits api={api} items={data.habits || []} refresh={refresh} />}
        {active === 'finance' && <Finance api={api} items={data.finance || []} refresh={refresh} dashboard={data.dashboard} />}
        {active === 'notes' && <Notes api={api} items={data.notes || []} refresh={refresh} />}
        {active === 'ai' && <AIPage api={api} goals={data.goals || []} />}
      </main>
    </div>
  );
}

function AuthScreen({ setToken, message, setMessage }) {
  const [mode, setMode] = useState('register');
  const [form, setForm] = useState({ name: 'Devansh Bhargava', email: '', password: '' });

  async function submit(e) {
    e.preventDefault();
    setMessage('');
    try {
      const response = await fetch(`${API_URL}/api/auth/${mode}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || 'Auth failed');
      localStorage.setItem('chief_token', payload.token);
      setToken(payload.token);
    } catch (error) {
      setMessage(error.message);
    }
  }

  return (
    <div className="authPage">
      <section className="heroPanel">
        <p className="eyebrow">Portfolio-grade full-stack AI app</p>
        <h1>AI Chief of Staff Pro</h1>
        <p>Goals, tasks, reminders, mood, habits, appointments, notes, finance and AI daily brief — built by Devansh Bhargava.</p>
        <div className="heroGrid">
          <span>JWT Auth</span><span>User Isolation</span><span>AI Fallback</span><span>SQLite</span><span>React</span><span>Express</span>
        </div>
      </section>
      <form className="authCard" onSubmit={submit}>
        <h2>{mode === 'register' ? 'Create account' : 'Login'}</h2>
        {mode === 'register' && <input placeholder="Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />}
        <input placeholder="Email" type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
        <input placeholder="Password" type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
        <button className="primary">{mode === 'register' ? 'Launch my OS' : 'Enter dashboard'}</button>
        {message && <div className="alert">{message}</div>}
        <button type="button" className="ghost" onClick={() => setMode(mode === 'register' ? 'login' : 'register')}>
          {mode === 'register' ? 'Already have an account? Login' : 'New here? Register'}
        </button>
      </form>
    </div>
  );
}

function Dashboard({ data = {} }) {
  const cards = [
    ['Open Tasks', data.taskSummary?.todo || 0, ListTodo],
    ['High Priority', data.taskSummary?.highPriority || 0, TrendingUp],
    ['Active Goals', data.goals?.filter(g => g.status === 'active').length || 0, Target],
    ['Balance', `₹${Math.round(data.financeSummary?.balance || 0)}`, CircleDollarSign]
  ];
  return (
    <div className="gridPage">
      <div className="statsGrid">
        {cards.map(([label, value, Icon]) => <div className="stat" key={label}><Icon size={22}/><span>{label}</span><strong>{value}</strong></div>)}
      </div>
      <Panel title="CEO Priorities">
        {(data.goals || []).slice(0, 4).map(goal => <Row key={goal.id} title={goal.title} meta={`${goal.progress}% • ${goal.deadline || 'No deadline'}`} />)}
      </Panel>
      <Panel title="Upcoming Reminders">
        {(data.reminders || []).slice(0, 5).map(item => <Row key={item.id} title={item.title} meta={formatDate(item.remindAt)} />)}
      </Panel>
      <Panel title="Appointments">
        {(data.appointments || []).slice(0, 5).map(item => <Row key={item.id} title={item.title} meta={`${formatDate(item.startsAt)} • ${item.location || 'No location'}`} />)}
      </Panel>
      <Panel title="Mood Signals">
        {(data.moods || []).slice(0, 5).map(item => <Row key={item.id} title={item.mood} meta={`Energy ${item.energy}/10 • Stress ${item.stress}/10`} />)}
      </Panel>
    </div>
  );
}

function Tasks({ api, items, refresh }) {
  const [form, setForm] = useState({ title: '', priority: 'high', dueDate: '', category: 'Career' });
  return <Module title="Task Command Center" onSubmit={async () => { await api('/api/tasks', { method: 'POST', body: JSON.stringify(form) }); setForm({ ...form, title: '' }); refresh(); }} form={form} setForm={setForm} fields={[['title','Task title'], ['dueDate','Due date'], ['category','Category']]}>
    {items.map(item => <Row key={item.id} title={item.title} meta={`${item.status} • ${item.priority} • ${item.category}`} actions={<><button onClick={async()=>{await api(`/api/tasks/${item.id}`,{method:'PATCH',body:JSON.stringify({status:item.status==='done'?'todo':'done'})});refresh();}}><CheckCircle2 size={16}/> Done</button><Delete api={api} path={`/api/tasks/${item.id}`} refresh={refresh}/></>} />)}
  </Module>;
}

function Goals({ api, items, refresh }) {
  const [form, setForm] = useState({ title: '', why: '', deadline: '', progress: 0 });
  return <Module title="Goal Operating System" onSubmit={async () => { await api('/api/goals', { method: 'POST', body: JSON.stringify(form) }); setForm({ title: '', why: '', deadline: '', progress: 0 }); refresh(); }} form={form} setForm={setForm} fields={[['title','Goal title'], ['why','Why it matters'], ['deadline','Deadline'], ['progress','Progress %']]}> 
    {items.map(item => <Row key={item.id} title={item.title} meta={`${item.progress}% • ${item.status} • ${item.deadline || 'No deadline'}`} actions={<><button onClick={async()=>{await api(`/api/goals/${item.id}`,{method:'PATCH',body:JSON.stringify({progress:Math.min(100, item.progress+10)})});refresh();}}>+10%</button><Delete api={api} path={`/api/goals/${item.id}`} refresh={refresh}/></>} />)}
  </Module>;
}

function Reminders({ api, items, refresh }) {
  const [form, setForm] = useState({ title: '', remindAt: '', channel: 'in-app' });
  return <Module title="Reminder Engine" onSubmit={async () => { await api('/api/reminders', { method: 'POST', body: JSON.stringify(form) }); setForm({ title: '', remindAt: '', channel: 'in-app' }); refresh(); }} form={form} setForm={setForm} fields={[['title','Reminder'], ['remindAt','YYYY-MM-DDTHH:mm'], ['channel','Channel']]}> 
    {items.map(item => <Row key={item.id} title={item.title} meta={`${formatDate(item.remindAt)} • ${item.status}`} actions={<><button onClick={async()=>{await api(`/api/reminders/${item.id}`,{method:'PATCH',body:JSON.stringify({status:'done'})});refresh();}}>Mark done</button><Delete api={api} path={`/api/reminders/${item.id}`} refresh={refresh}/></>} />)}
  </Module>;
}

function Appointments({ api, items, refresh }) {
  const [form, setForm] = useState({ title: '', startsAt: '', location: '', notes: '' });
  return <Module title="Appointment Manager" onSubmit={async () => { await api('/api/appointments', { method: 'POST', body: JSON.stringify(form) }); setForm({ title: '', startsAt: '', location: '', notes: '' }); refresh(); }} form={form} setForm={setForm} fields={[['title','Appointment'], ['startsAt','YYYY-MM-DDTHH:mm'], ['location','Location'], ['notes','Notes']]}> 
    {items.map(item => <Row key={item.id} title={item.title} meta={`${formatDate(item.startsAt)} • ${item.location || 'No location'}`} actions={<Delete api={api} path={`/api/appointments/${item.id}`} refresh={refresh}/>} />)}
  </Module>;
}

function Mood({ api, items, refresh }) {
  const [form, setForm] = useState({ mood: 'Focused', energy: 7, stress: 4, note: '' });
  return <Module title="Mood Uplift System" onSubmit={async () => { await api('/api/moods', { method: 'POST', body: JSON.stringify(form) }); setForm({ ...form, note: '' }); refresh(); }} form={form} setForm={setForm} fields={[['mood','Mood'], ['energy','Energy 1-10'], ['stress','Stress 1-10'], ['note','What happened?']]}> 
    {items.map(item => <Row key={item.id} title={item.mood} meta={`Energy ${item.energy}/10 • Stress ${item.stress}/10 • ${item.note || 'No note'}`} />)}
  </Module>;
}

function Habits({ api, items, refresh }) {
  const [form, setForm] = useState({ title: '', targetFrequency: 'daily' });
  return <Module title="Habit Tracker" onSubmit={async () => { await api('/api/habits', { method: 'POST', body: JSON.stringify(form) }); setForm({ title: '', targetFrequency: 'daily' }); refresh(); }} form={form} setForm={setForm} fields={[['title','Habit'], ['targetFrequency','Frequency']]}> 
    {items.map(item => <Row key={item.id} title={item.title} meta={`${item.targetFrequency} • ${item.completions || 0} completions`} actions={<><button onClick={async()=>{await api(`/api/habits/${item.id}/log`,{method:'POST',body:JSON.stringify({})});refresh();}}>Log today</button><Delete api={api} path={`/api/habits/${item.id}`} refresh={refresh}/></>} />)}
  </Module>;
}

function Finance({ api, items, refresh, dashboard }) {
  const [form, setForm] = useState({ type: 'expense', amount: '', category: 'Food', note: '' });
  return <div className="gridPage"><div className="statsGrid"><div className="stat"><span>Income</span><strong>₹{Math.round(dashboard?.financeSummary?.income || 0)}</strong></div><div className="stat"><span>Expense</span><strong>₹{Math.round(dashboard?.financeSummary?.expense || 0)}</strong></div><div className="stat"><span>Balance</span><strong>₹{Math.round(dashboard?.financeSummary?.balance || 0)}</strong></div></div><Module title="Finance Tracker" onSubmit={async () => { await api('/api/finance', { method: 'POST', body: JSON.stringify(form) }); setForm({ ...form, amount: '', note: '' }); refresh(); }} form={form} setForm={setForm} fields={[['type','income or expense'], ['amount','Amount'], ['category','Category'], ['note','Note']]}> 
    {items.map(item => <Row key={item.id} title={`${item.type === 'income' ? '+' : '-'} ₹${item.amount} • ${item.category}`} meta={`${item.entryDate} • ${item.note || 'No note'}`} actions={<Delete api={api} path={`/api/finance/${item.id}`} refresh={refresh}/>} />)}
  </Module></div>;
}

function Notes({ api, items, refresh }) {
  const [form, setForm] = useState({ title: '', content: '' });
  return <Module title="Knowledge Notes" onSubmit={async () => { await api('/api/notes', { method: 'POST', body: JSON.stringify(form) }); setForm({ title: '', content: '' }); refresh(); }} form={form} setForm={setForm} fields={[['title','Note title'], ['content','Content']]}> 
    {items.map(item => <Row key={item.id} title={item.title} meta={item.content?.slice(0, 140)} actions={<Delete api={api} path={`/api/notes/${item.id}`} refresh={refresh}/>} />)}
  </Module>;
}

function AIPage({ api, goals }) {
  const [brief, setBrief] = useState('Click generate to get your executive daily brief.');
  const [goalTitle, setGoalTitle] = useState(goals[0]?.title || 'Get a finance internship');
  const [plan, setPlan] = useState('');
  const [loading, setLoading] = useState(false);
  return (
    <div className="gridPage">
      <Panel title="AI Daily Brief">
        <pre>{brief}</pre>
        <button className="primary" onClick={async()=>{setLoading(true); const r = await api('/api/ai/daily-brief', { method:'POST', body:JSON.stringify({}) }); setBrief(`${r.brief}\n\nSource: ${r.source}`); setLoading(false);}}>{loading ? 'Generating...' : 'Generate brief'}</button>
      </Panel>
      <Panel title="Goal Breakdown">
        <input value={goalTitle} onChange={e=>setGoalTitle(e.target.value)} />
        <button className="primary" onClick={async()=>{const r=await api('/api/ai/goal-breakdown',{method:'POST',body:JSON.stringify({title:goalTitle})}); setPlan(`${r.plan}\n\nSource: ${r.source}`);}}>Break down goal</button>
        <pre>{plan}</pre>
      </Panel>
    </div>
  );
}

function Module({ title, onSubmit, form, setForm, fields, children }) {
  return <div className="gridPage"><Panel title={title}><form className="inlineForm" onSubmit={e=>{e.preventDefault(); onSubmit();}}>{fields.map(([key, placeholder]) => <input key={key} placeholder={placeholder} value={form[key] ?? ''} onChange={e=>setForm({ ...form, [key]: e.target.value })} />)}<button className="primary">Add</button></form></Panel><Panel title="Records">{children?.length ? children : <p className="empty">Nothing here yet.</p>}</Panel></div>;
}

function Panel({ title, children }) {
  return <section className="panel"><h2>{title}</h2>{children}</section>;
}

function Row({ title, meta, actions }) {
  return <div className="row"><div><strong>{title}</strong><span>{meta}</span></div>{actions && <div className="rowActions">{actions}</div>}</div>;
}

function Delete({ api, path, refresh }) {
  return <button className="danger" onClick={async()=>{await api(path,{method:'DELETE'});refresh();}}>Delete</button>;
}

function formatDate(value) {
  if (!value) return 'No date';
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? value : d.toLocaleString();
}

createRoot(document.getElementById('root')).render(<App />);
