# Feature Matrix

| Feature | Status | Notes |
|---|---:|---|
| JWT login/signup | Done | User-specific token auth |
| User data isolation | Done | Every table scoped by userId |
| Dashboard | Done | Tasks, goals, reminders, appointments, mood, finance |
| Task manager | Done | Priority, status, category, due date |
| Goal tracker | Done | Why, progress, deadline, status |
| Reminder engine | Done | In-app scheduled records |
| Appointments | Done | Start time, location, notes |
| Mood uplift | Done | Mood, energy, stress, note |
| Habits | Done | Habits + daily log endpoint |
| Finance | Done | Income/expense summary |
| Notes | Done | Personal knowledge capture |
| AI daily brief | Done | Claude optional + local fallback |
| AI goal breakdown | Done | Claude optional + local fallback |
| Security basics | Done | Helmet, CORS, rate limiting, bcrypt |
| Google Calendar sync | Roadmap | Add OAuth + Calendar API |
| WhatsApp/Email notifications | Roadmap | Add provider integration |
| PostgreSQL migration | Roadmap | For production deployment |
