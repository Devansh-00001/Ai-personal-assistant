# Run Guide

## 1. Install

```bash
npm install
```

## 2. Configure environment

```bash
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env
```

Edit `backend/.env` and set a strong `JWT_SECRET`.

## 3. Start both apps

```bash
npm run dev
```

Frontend: `http://localhost:5173`  
Backend: `http://localhost:5000/health`

## 4. First demo

1. Register with your email.
2. Open Dashboard.
3. Generate AI Brief.
4. Add a goal.
5. Use Goal Breakdown.
6. Add reminder + appointment.
7. Log mood + habit.
8. Show finance tracker.

## Common issue

If Claude AI does not work, leave it. The app intentionally uses a local fallback so demos still work without an API key.
