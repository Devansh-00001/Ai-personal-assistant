# AI Chief of Staff Pro

**Created by Devansh Bhargava**

A portfolio-grade AI productivity operating system designed to feel like a personal executive assistant: goals, tasks, reminders, habits, appointments, mood check-ins, notes, finance tracking, and AI daily briefs in one full-stack app.

## Why this project stands out

Most productivity apps only store tasks. This project adds a real assistant architecture:

- **JWT authentication** with user-specific data isolation
- **Executive dashboard** with priorities, reminders, appointments, and progress metrics
- **Goal operating system** with progress, deadlines, and AI breakdowns
- **Reminder and appointment manager** for daily planning
- **Mood uplift module** with check-ins and AI/local coaching fallback
- **Habit tracker** with daily logs and streak-ready schema
- **Finance tracker** for income/expense visibility
- **Notes system** for personal knowledge capture
- **AI daily briefing** using Anthropic Claude when configured, with a local fallback when no API key exists
- **Security basics**: Helmet, CORS config, rate limiting, request limits, password hashing
- **Portfolio-ready documentation** with roadmap, architecture, and professional setup

## Tech stack

| Layer | Technology |
|---|---|
| Frontend | React + Vite + CSS |
| Backend | Node.js + Express |
| Database | SQLite |
| Auth | JWT + bcryptjs |
| AI | Optional Anthropic Claude SDK |
| Security | Helmet, CORS, rate limiting |

## Quick start

```bash
npm install
cp .env.example backend/.env
cp .env.example frontend/.env
npm run dev
```

Open frontend:

```text
http://localhost:5173
```

Backend health check:

```text
http://localhost:5000/health
```

## Demo account

Create an account from the UI. The app seeds starter goals/tasks/habits for new users so the dashboard does not look empty.

## API overview

| Module | Routes |
|---|---|
| Auth | `/api/auth/register`, `/api/auth/login`, `/api/auth/me` |
| Dashboard | `/api/dashboard` |
| Tasks | `/api/tasks` |
| Goals | `/api/goals` |
| Reminders | `/api/reminders` |
| Appointments | `/api/appointments` |
| Mood | `/api/moods` |
| Habits | `/api/habits`, `/api/habits/:id/log` |
| Finance | `/api/finance` |
| Notes | `/api/notes` |
| AI | `/api/ai/daily-brief`, `/api/ai/goal-breakdown` |

## AI setup

AI features work without an API key using a deterministic local fallback. For Claude-powered responses:

```bash
ANTHROPIC_API_KEY=your_key_here
CLAUDE_MODEL=claude-3-5-sonnet-latest
```

## Portfolio positioning

Use this repo as a full-stack case study:

> “I built an AI Chief of Staff that combines productivity, goal tracking, mood intelligence, reminders, appointments, finance visibility, and AI planning into a single personal operating system.”

## Roadmap

- Google Calendar sync
- Push/email/WhatsApp notifications
- PostgreSQL migration
- OAuth login
- File uploads and document memory
- Deployment with Docker + managed database
- Mobile-first PWA support

## Ownership

Copyright © 2026 Devansh Bhargava. All rights reserved.
